# Simple-Music-Player
A simple music player using Java NetBeans
